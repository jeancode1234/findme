---
name: GeoLink Precision
colors:
  surface: '#fbf9f8'
  surface-dim: '#dbd9d9'
  surface-bright: '#fbf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#efeded'
  surface-container-high: '#eae8e7'
  surface-container-highest: '#e4e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#43474d'
  inverse-surface: '#303030'
  inverse-on-surface: '#f2f0f0'
  outline: '#74777e'
  outline-variant: '#c4c6ce'
  surface-tint: '#49607e'
  primary: '#000f22'
  on-primary: '#ffffff'
  primary-container: '#0a2540'
  on-primary-container: '#768dad'
  inverse-primary: '#b0c8eb'
  secondary: '#006d41'
  on-secondary: '#ffffff'
  secondary-container: '#85f6b4'
  on-secondary-container: '#007144'
  tertiary: '#210700'
  on-tertiary: '#ffffff'
  tertiary-container: '#431600'
  on-tertiary-container: '#e76211'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d2e4ff'
  primary-fixed-dim: '#b0c8eb'
  on-primary-fixed: '#001c37'
  on-primary-fixed-variant: '#314865'
  secondary-fixed: '#88f9b7'
  secondary-fixed-dim: '#6bdc9d'
  on-secondary-fixed: '#002110'
  on-secondary-fixed-variant: '#005230'
  tertiary-fixed: '#ffdbcc'
  tertiary-fixed-dim: '#ffb694'
  on-tertiary-fixed: '#351000'
  on-tertiary-fixed-variant: '#7b2f00'
  background: '#fbf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e2'
typography:
  headline-xl:
    fontFamily: Public Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
  headline-lg:
    fontFamily: Public Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Public Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Public Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Public Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Public Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Public Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Public Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.05em
  headline-lg-mobile:
    fontFamily: Public Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style

The design system is engineered for a technical, high-precision geospatial utility. The brand personality is authoritative, reliable, and functional, targeting logistics professionals, developers, and government agencies. 

The visual style is **Corporate / Modern** with a focus on data density and information hierarchy. It leverages high-contrast color palettes to ensure legibility in field environments and professional office settings. The interface avoids unnecessary ornamentation, favoring clean lines, purposeful whitespace, and a systematic approach to depth that emphasizes structural clarity. The dual-mode architecture ensures that the "Deep Tech" aesthetic remains consistent whether the user is in a bright daylight environment or a low-light command center.

## Colors

The palette is anchored by **Deep Tech Blue (#0a2540)**, serving as the primary brand identifier and foundational surface color in dark mode. **Emerald Green (#2DA56B)** is reserved for high-priority actions, success states, and precision indicators.

### Accessibility Standards
- **Contrast:** Maintain a minimum of 4.5:1 for body text and 3:1 for large display text across both themes.
- **Interactive States:** Use a 10% overlay (white in dark mode, black in light mode) for hover states, and 20% for active/pressed states.
- **Semantic Mapping:** Success uses Emerald Green, Warnings use Action Orange (#F26A1B), and Errors use a high-visibility Red (#D63031).

## Typography

This design system utilizes **Public Sans** across all levels to maintain its institutional and technical character. It is a neutral, highly legible grotesque typeface that performs exceptionally well in data-heavy interfaces.

- **Weight Strategy:** Use Bold (700) for primary headers to establish a strong hierarchy. Medium (600) is preferred for labels and interactive components like buttons.
- **Optical Sizing:** For text smaller than 12px (e.g., map annotations), increase letter-spacing by 0.05em to preserve legibility in dark mode.
- **Color Contrast:** Text-primary should be used for headlines, while text-secondary is utilized for body copy and supporting metadata to reduce visual noise.

## Layout & Spacing

The system employs a **12-column fluid grid** for desktop and a **4-column grid** for mobile. A strict 4px base unit governs all spatial relationships, ensuring a rhythmic and predictable layout.

- **Internal Padding:** Components such as cards and modals should use `lg` (24px) padding for primary content and `md` (16px) for nested elements.
- **Vertical Rhythm:** Maintain consistent gaps between sections using `xl` (32px) or `2xl` (48px) to prevent information density from becoming overwhelming.
- **Breakpoints:** 
  - Mobile: < 600px
  - Tablet: 600px - 1024px
  - Desktop: > 1024px

## Elevation & Depth

Visual hierarchy is achieved through **Tonal Layers** rather than heavy shadows.

- **Light Mode:** Use subtle, low-opacity shadows (Blur 8px, Y 4px, Color #0A2540 at 5% opacity) to lift cards from the background. 
- **Dark Mode:** Depth is communicated through surface color stepping. The base background is the darkest (#05111D), and elevated components (cards, menus) use a lighter blue-grey (#1E293B) to simulate proximity to the light source. 
- **Outlines:** In both modes, interactive fields and containers use a 1px border. In dark mode, this border provides essential definition against the dark background.

## Shapes

The design system uses a **Soft (rounded-sm)** shape language to balance professional rigor with modern approachability.

- **Global Radius:** All standard components (buttons, inputs, cards) use a 4px (0.25rem) corner radius.
- **Large Components:** Modals or large dashboard containers may scale up to `rounded-lg` (8px) to soften the visual impact of large surfaces.
- **Consistency:** Rounding must be applied consistently to both the outer container and any inner focused states or selection indicators.

## Components

### Buttons
- **Primary:** Background Emerald Green, Text White. Solid fill.
- **Secondary:** Outline 1px Deep Tech Blue (Light Mode) or Light Grey (Dark Mode).
- **Interactive States:** Hover state includes a subtle brightness shift (+10% for dark mode, -10% for light mode).

### Input Fields
- **Default:** 1px border (#E2E8F0 light / #1E293B dark). 
- **Focus:** 2px border using Emerald Green.
- **Labels:** Positioned above the field using `label-md` typography.

### Cards
- **Container:** Background surface-primary with a 1px border-subtle.
- **Header:** Include a subtle bottom border to separate titles from content.

### Chips & Badges
- **Status:** Use low-saturation background tints of the semantic colors (Success, Warning, Error) with high-saturation text to ensure accessibility without overwhelming the UI.

### Navigation
- **Sidebar/Header:** In dark mode, the navigation bar should use the primary brand color (#0a2540) to create a distinct anchor for the interface.